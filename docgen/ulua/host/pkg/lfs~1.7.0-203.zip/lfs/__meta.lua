return {
  description = "luafilesystem : File System Library for the Lua Programming Language",
  homepage = "",
  license = "MIT/X11",
  name = "lfs",
  require = {
    luajit = "2.0"
  },
  version = "1.7.0-203"
}