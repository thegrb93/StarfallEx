return {
  description = "luasocket : Network support for the Lua language",
  homepage = "http://luaforge.net/projects/luasocket/",
  license = "MIT",
  require = {
    ltn12 = "2.0.2-603",
    luajit = "2.0",
    socket = "2.0.2-603"
  },
  version = "2.0.2-603"
}