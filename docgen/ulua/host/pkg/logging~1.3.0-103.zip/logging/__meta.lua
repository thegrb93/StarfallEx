return {
  description = "lualogging : A simple API to use logging features",
  homepage = "https://github.com/Neopallium/lualogging",
  license = "MIT/X11",
  require = {
    ltn12 = "2.0.2-6",
    luajit = "2.0",
    mime = "2.0.2-6",
    socket = "2.0.2-6"
  },
  version = "1.3.0-103"
}