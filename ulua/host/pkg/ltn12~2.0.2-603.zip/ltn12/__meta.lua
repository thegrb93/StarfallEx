return {
  description = "luasocket : Network support for the Lua language",
  homepage = "http://luaforge.net/projects/luasocket/",
  license = "MIT",
  require = {
    luajit = "2.0",
    mime = "2.0.2-603",
    socket = "2.0.2-603"
  },
  version = "2.0.2-603"
}